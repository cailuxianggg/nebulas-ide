import React from 'react';

class ContractStar extends React.Component{
	render(){
		const {uuid,star} = this.props;
		return (
				<div>打赏</div>
			)

	}
}

export default ContractStar;